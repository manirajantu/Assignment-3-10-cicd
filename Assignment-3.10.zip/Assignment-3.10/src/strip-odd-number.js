module.exports = function(numberArr){
    return numberArr.filter(n => n % 2 === 0);
}